from flask import Flask, jsonify

app = Flask(__name__)

@app.route("/")
def home():
    return "Dockerized DevOps Project Running Successfully"

@app.route("/health")
def health():
    return jsonify({"status":"healthy"})

@app.route("/about")
def about():
    return jsonify({
        "project":"Dockerized Flask DevOps Project",
        "version":"1.0"
    })

@app.route("/users")
def users():
    return jsonify([
        {"id":1,"name":"Rubika"},
        {"id":2,"name":"Admin"}
    ])

@app.route("/status")
def status():
    return jsonify({
        "application":"running",
        "docker":"enabled",
        "environment":"development"
    })

@app.route("/contact")
def contact():
    return jsonify({
        "email":"admin@example.com",
        "phone":"+91-0000000000"
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
